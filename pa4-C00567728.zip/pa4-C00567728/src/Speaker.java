public class Speaker {
    private String name;
    private double minDb;
    private double maxDb;

    public Speaker(String name, double min, double max){
        this.name = name;
        minDb = min;
        maxDb = max;
    }
    public String getName(){
        return name;
    }
    public double getMinDb(){
        return minDb;
    }
    public double getMaxDb(){
        return maxDb;
    }
    public boolean isClipping(double outputDB){
        if (outputDB > maxDb){
            return true;
        }else{return false;}
    }
    public boolean isAudible(double outputDB){
        if (outputDB < minDb){
            return false;
        }else{return true;}
    }
    public String toString(){
        return "Speaker [Name : " + getName() + ", Min dB: " + getMinDb() + ", Max dB: " + getMaxDb() + "]";
    }

}
