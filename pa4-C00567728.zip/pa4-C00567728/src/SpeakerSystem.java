public class SpeakerSystem {
    private Amplifier amplifier;
    private PreampInput[] inputs;
    private int numInputs;
    private Speaker[] speakers;
    private int numSpeakers;
    public SpeakerSystem(Amplifier amplifier) {
        this.amplifier = amplifier;
        this.inputs = new PreampInput[0];
        this.numInputs = 0;
        this.speakers = new Speaker[0];
        this.numSpeakers = 0;
    }
    public void addInput(PreampInput input){
        if (numInputs == inputs.length) {
            PreampInput[] temp = new PreampInput[inputs.length + 1];
            for (int i = 0; i < inputs.length; i++) {
                temp[i] = inputs[i];
            }
            inputs = temp;
        }
        inputs[numInputs] = input;
        numInputs++;
        System.out.println("Input added: " + input);
    }
    public void addSpeaker(Speaker speaker){
        if (numSpeakers == speakers.length){
            Speaker[] temp = new Speaker[speakers.length + 1];
            for (int i = 0; i < speakers.length; i++){
                temp[i] = speakers[i];
            }
            speakers = temp;
        }
        speakers[numSpeakers] = speaker;
        numSpeakers++;
        System.out.println("Speaker added: " + speaker);
    }
    public boolean removeInput(int index){
        if (index < 0 || index >= numInputs) {
            System.out.println("Invalid index. No input removed.");
            return false;
        }
        System.out.println("Removed input at index " + index + ": " + inputs[index]);
        for (int i = index; i < numInputs - 1; i++) {
            inputs[i] = inputs[i + 1];
        }
        inputs[numInputs - 1] = null;
        numInputs--;
        return true;
    }
    public boolean removeInputByName(String name){
        PreampInput tempInput;
        for (int i = 0; i < numInputs; i++) {
            if (inputs[i].getName().equals(name)) {
                tempInput = inputs[i];
                for (int j = i; j < numInputs - 1; j++) {
                    inputs[j] = inputs[j + 1];
                }
                inputs[numInputs - 1] = null;
                numInputs--;

                System.out.println("Removed input with name: " + tempInput);
                return true;
            }
        }
        System.out.println("No input with name \"" + name + "\" found.");
        return false;
    }
    public boolean removeInputByHighestLevel() {
        if (numInputs == 0) {
            System.out.println("No inputs to remove.");
            return false;
        }
        int temp = 0;
        int highestIndex = 0;
        for (int i = 1; i < numInputs; i++) {
            if (inputs[i].getLevel() > inputs[highestIndex].getLevel()) {
                highestIndex = i;
            }
        }
        System.out.println("Removed Highest Input: " + inputs[highestIndex]);
        for (int i = highestIndex; i < numInputs - 1; i++) {
            inputs[i] = inputs[i + 1];
        }
        numInputs--;
        PreampInput[] temp1 = new PreampInput[numInputs];
        for (int i = 0; i < numInputs; i++) {
            temp1[i] = inputs[i];
        }
        inputs = temp1;

        return true;
    }
    public boolean removeInputByLowestLevel() {
        if (numInputs == 0) {
            System.out.println("\nNo inputs to remove.");
            return false;
        }
        int lowestIndex = 0;
        for (int i = 1; i < numInputs; i++) {
            if (inputs[i].getLevel() < inputs[lowestIndex].getLevel()) {
                lowestIndex = i;
            }
        }
        System.out.println("\nRemoved Lowest Input: " + inputs[lowestIndex]);
        for (int i = lowestIndex; i < numInputs - 1; i++) {
            inputs[i] = inputs[i + 1];
        }
        numInputs--;
        PreampInput[] temp = new PreampInput[numInputs];
        for (int i = 0; i < numInputs; i++) {
            temp[i] = inputs[i];
        }
        inputs = temp;
        return true;
    }
        public void runDiagnostics() {
        System.out.println("\nRunning Diagnostics...");
        if (numInputs == 0 || numSpeakers == 0) {
            System.out.println("Diagnostics cannot be run without inputs or speakers.");
            return;
        }

        double combinedInputLevel = 0.0;
        for (int i = 0; i < numInputs; i++) {
            combinedInputLevel += inputs[i].getLevel();
        }

        double outputLevel = amplifier.amplify(combinedInputLevel);

        System.out.printf("Amplifier power: " + amplifier.getWattage() + " W --> Gain: %.2f dB", amplifier.computeGain());
        System.out.println("\nCombined input level: " + combinedInputLevel + " dB");
        System.out.printf("Total output level: %.2f dB", outputLevel);
        System.out.println("\n\n-- Speaker Output --");

        for (int i = 0; i < numSpeakers; i++) {
            Speaker speaker = speakers[i];
            System.out.println("\nSpeaker: " + speaker.getName());
            System.out.println("Acceptable range: " + speaker.getMinDb() + " dB to " + speaker.getMaxDb() + " dB");

            if (speaker.isClipping(outputLevel)) {
                System.out.println("Result: Signal is TOO LOUD (Clipping)");
                System.out.println("Output: Distorted sound");
            } else if (!speaker.isAudible(outputLevel)) {
                System.out.println("Result: Signal is TOO WEAK (Not Audible)");
                System.out.println("Output: No sound");
            } else {
                System.out.println("Result: Signal is within acceptable range");
                System.out.printf("Output: Playing at %.2f dB\n", outputLevel);
            }
        }
    }

    public void currentInputs(){

        System.out.println("\nCurrent Inputs: ");
        if (inputs.length == 0){
            System.out.println("No Inputs");
        }
        for (PreampInput e : inputs){
            System.out.println(e);
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("Amplifier:\n")
                .append("Power: ").append(amplifier.getWattage()).append(" W\n")
                .append("Gain: ").append(amplifier.computeGain()).append(" dB\n");

        sb.append("\nInputs:\n");
        if (numInputs == 0) {
            sb.append("No inputs available.\n");
        } else {
            for (int i = 0; i < numInputs; i++) {
                sb.append("- ").append(inputs[i].toString()).append("\n");
            }
        }

        sb.append("Speakers:\n");
        if (numSpeakers == 0) {
            sb.append("No speakers available.\n");
        } else {
            for (int i = 0; i < numSpeakers; i++) {
                sb.append("- ").append(speakers[i].toString()).append("\n");
            }
        }

        return sb.toString();
    }

}
