//------ Cole Dicke-----
//------ C00567728-----
// CMPS 260, Section------ 003
// Programming Assignment :------ 4
// Due Date :------ 4/14/2025-----
// Program Description:--- This assignment allows students to practice object-oriented design by modeling real-world
// components with class relationships and work with collections and dynamic state changes
// ===================================
// *** Certificate of Authenticity ***
// ===================================
// I certify that all Java code in this project is entirely my own work,
// and I have not shared it with any person or website before the
// deadline or within the 24-hour extension period.


import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter amplifier wattage: ");
        double wattage = scanner.nextDouble();
        Amplifier amplifier = new Amplifier(wattage);

        SpeakerSystem speakerSystem = new SpeakerSystem(amplifier);

        System.out.println("\nInitial inputs added: ");

        speakerSystem.addInput(new PreampInput("Vocal Mic", -6.0));
        speakerSystem.addInput(new PreampInput("Vocal Mic", -4.0));
        speakerSystem.addInput(new PreampInput("Guitar", -10.0));
        speakerSystem.addInput(new PreampInput("Piano", -3.0));
        speakerSystem.addInput(new PreampInput("Drums", -2.0));


        System.out.println("\nSpeakers added:");

        speakerSystem.addSpeaker(new Speaker("Monitor A", 5.0, 35.0));
        speakerSystem.addSpeaker(new Speaker("Monitor B", 3.0, 40.0));
        System.out.println();

        speakerSystem.removeInput(2);

        speakerSystem.removeInputByName("Piano");

        speakerSystem.removeInputByHighestLevel();

        //removed the call to remove by lowest input due to the moodle changelog of pa4

        speakerSystem.currentInputs();

        speakerSystem.runDiagnostics();

        speakerSystem.removeInputByLowestLevel();

        speakerSystem.currentInputs();

        speakerSystem.runDiagnostics();

        System.out.println();

        speakerSystem.addInput(new PreampInput("Condenser Mic", -2.0));

        speakerSystem.currentInputs();

        speakerSystem.runDiagnostics();

        scanner.close();
    }
}
