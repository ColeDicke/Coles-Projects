public class PreampInput {
    private String name;
    private double level;

    public void setName(String name){
        this.name = name;
    }
    public void setLevel(double level){
        if (level <= 0) {
            this.level = level;
        }else{
            System.out.println("Invalid decibel input. Setting to default value of -1.0.");
            this.level = -1.0;
        }
    }
    public String getName(){
        return name;
    }
    public double getLevel(){
        return level;
    }
    public PreampInput(String name, double level){
        this.name = name;
        setLevel(level);
    }
    public String toString(){
        return  "- " + getName() + " (" + getLevel() + " dB)";
    }
}
