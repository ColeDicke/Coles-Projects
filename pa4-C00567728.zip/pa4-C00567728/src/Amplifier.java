public class Amplifier {
    private final double wattage;
    public double getWattage(){
        return wattage;
    }
    public Amplifier(double wattage){
        if (wattage <= 0){
            System.out.println("Invalid wattage. Setting to default value of 1.0");
            this.wattage = 1.0;
        } else {
            this.wattage = wattage;
        }
    }
    public double computeGain(){
        return 10 * Math.log10(wattage);
    }
    public double amplify(double inputDB){
        return (inputDB + this.computeGain());

    }
    public String toString(){
        return "Amplifier [Wattage: " + wattage + " W, Gain: " + computeGain() + " dB]";

    }

}
